package com.example.homework6

interface OnShortClick {
    fun onItemShortClick(catItems: CatItems)

}